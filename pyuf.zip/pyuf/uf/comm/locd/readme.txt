This folder is Python implementation of 6LoCD Protocol Stack.

The 6LoCD protocol, almost like: 6LoWPAN,
both are Compression Format for IPv6 Datagrams.

Reference to C implementation of 6LoCD Protocol Stack for details and documents.

